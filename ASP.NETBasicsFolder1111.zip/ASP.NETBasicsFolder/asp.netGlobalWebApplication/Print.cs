﻿namespace asp.netGlobalWebApplication
{
    internal class Print
    {
    }
}