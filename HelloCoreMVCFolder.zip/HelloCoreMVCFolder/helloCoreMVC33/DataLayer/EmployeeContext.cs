﻿using Microsoft.EntityFrameworkCore;
using HelloCoreMVC33.Models;

namespace HelloCoreMVC33.DataLayer
{
    public class EmployeeContext : DbContext
    {
        public EmployeeContext(DbContextOptions<EmployeeContext> options) : base(options)
        {

        }
        public DbSet<Employee> Employees { get; set; }
    }
}
