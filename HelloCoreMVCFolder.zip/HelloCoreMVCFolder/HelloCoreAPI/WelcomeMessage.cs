﻿namespace HelloCoreAPI
{
    public class WelcomeMessage
    {
        public string Message { get; }

        public WelcomeMessage(string message)
        {
            Message = message;
        }
    }
}
